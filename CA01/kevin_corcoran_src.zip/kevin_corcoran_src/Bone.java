class Bone{
  String printString = "$==$";

  public String toString(){
    return printString;
  }
}
