class Fish{
  String printString = "}==*->";

  public String toString(){
    return printString;
  }
}
