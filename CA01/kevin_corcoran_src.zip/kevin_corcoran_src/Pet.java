abstract class Pet{
  String name;
  String gender;
  String sound;

  Pet(String name, String gender, String sound){
    this.name = name;
    this.gender = gender;
    this.sound = sound;
  }
}
