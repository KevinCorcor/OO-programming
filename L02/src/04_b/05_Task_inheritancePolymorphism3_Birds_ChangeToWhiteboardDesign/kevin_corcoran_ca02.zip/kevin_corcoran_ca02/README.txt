Run from within src folder:

javac -d ./../bin/ *.java ; java -cp ./../bin BirdMaker
