//TO DO: Make this class abstract
abstract class FlyingBird extends Bird {

	FlyingBird(){
		canFly = true;
	}
}
