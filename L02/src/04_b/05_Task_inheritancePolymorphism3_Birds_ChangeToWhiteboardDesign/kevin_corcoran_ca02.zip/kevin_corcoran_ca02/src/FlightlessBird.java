//TO DO: Make this class abstract
abstract class FlightlessBird extends Bird {

	FlightlessBird() {
		canFly = false;
	}
}
